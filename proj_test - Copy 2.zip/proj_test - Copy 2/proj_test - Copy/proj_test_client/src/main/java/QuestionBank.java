public class QuestionBank {
    public static String[][] hardModeQuestions = new String[6][7];
    public static String[][] hardModeAnswers = new String[6][7];
}

// mvn exec:java